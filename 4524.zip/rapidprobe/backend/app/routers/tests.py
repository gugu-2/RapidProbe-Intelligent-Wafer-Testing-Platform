from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Wafer, TestResult
from ..hardware.scpi_driver import SCPIInstrument
from ..hardware.rest_driver import RESTInstrument
from ..routers.auth import get_current_user
from ..schemas import TestResult

router = APIRouter()

@router.post("/run", dependencies=[Depends(get_current_user)])
def run_test(wafer_id: int, instrument_type: str, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    wafer = db.query(Wafer).get(wafer_id)
    if not wafer:
        raise HTTPException(status_code=404, detail="Wafer not found")
    instr = SCPIInstrument(address="GPIB0::14") if instrument_type == "SCPI" else RESTInstrument(base_url="http://192.168.0.50/api")
    background_tasks.add_task(execute_test, instr, wafer_id, db)
    return {"status": "Test started", "wafer_id": wafer_id}

def execute_test(instr, wafer_id, db):
    results = instr.run_test({"pattern": "full_wafer_scan"})
    for die in results["die_data"]:
        tr = TestResult(wafer_id=wafer_id, die_x=die["x"], die_y=die["y"],
                        test_name=die["test"], result_value=die["value"])
        db.add(tr)
    db.commit()
