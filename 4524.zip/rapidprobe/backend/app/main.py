from fastapi import FastAPI
from .database import Base, engine
from .routers import auth, users, tests, analytics

Base.metadata.create_all(bind=engine)
app = FastAPI(title="RapidProbe Wafer Test API")

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(users.router, prefix="/users", tags=["users"])
app.include_router(tests.router, prefix="/tests", tags=["tests"])
app.include_router(analytics.router, prefix="/analytics", tags=["analytics"])
